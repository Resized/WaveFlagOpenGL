#include "glut.h"
#include <stdlib.h>
#include <time.h>
#include <math.h>

const int N = 100;
const int W = 600;// window width
const int H = 600;// window height

const double PI = 3.14;

typedef struct {
	double x, y;
} POINT_2D;

typedef struct {
	int r, g, b; // 0..255
}MY_COLOR;

unsigned char pix[H][W][3]; // red,green and blue layers
double offset = 0;
bool click = false;
POINT_2D first_point;



void init()
{
	int i,j;
	glClearColor(0.5,0.5,0.5,0);// color of window background

	srand(time(NULL));

	for (i = 0; i < H; i++)
		for (j = 0; j < W; j++)
		{
			pix[i][j][0] = 255; // R
			pix[i][j][1] = 0; // G
			pix[i][j][2] = 0; // B
		}

}

void DrawLine(POINT_2D p1, POINT_2D p2,MY_COLOR color) {
	int i, j,start,stop;
	double a, b;

	if (p1.x != p2.x)
	{
		a = ((double)p2.y - p1.y) / (p2.x - p1.x);
		if (fabs(a) < 1 )
		{
			b = p1.y - a * p1.x;
			if (p1.x < p2.x)
			{
				start = p1.x;
				stop = p2.x;
			}
			else
			{
				stop = p1.x;
				start = p2.x;
			}
			for (j = start; j <= stop; j++)
			{
				i = a * j + b;// y = ax+b
				pix[i][j][0] = color.r;
				pix[i][j][1] = color.g;
				pix[i][j][2] = color.b;
			}
		}
		else // fabs(slope) is > 1
		{
			a = 1 / a;
			b = p1.x - a * p1.y;
			if (p1.y < p2.y)
			{
				start = p1.y;
				stop = p2.y;
			}
			else
			{
				start = p2.y;
				stop = p1.y;
			}
			for (i = start; i<= stop; i++)
			{
				j = a * i + b;
				pix[i][j][0] = color.r;
				pix[i][j][1] = color.g;
				pix[i][j][2] = color.b;
			}
		}
	}

}

void DrawFlag()
{
	int i, j;
	int radius = 80;
	POINT_2D pts[6];
	POINT_2D center = { W / 2,H / 2 };

	// background
	for (i = 0; i < H; i++)
		for (j = 0; j < W; j++)
		{
			pix[i][j][0] = 190; // R
			pix[i][j][1] = 190; // G
			pix[i][j][2] = 190; // B
		}
	// the points are placed on circle of RADIUS on 
	// angles: 45,90,135, 225,270,315
	pts[0].x = center.x + radius * cos(PI / 6);
	pts[0].y = center.y - radius * sin(PI / 6);
	pts[1].x = center.x + radius * cos(PI / 2);
	pts[1].y = center.y - radius * sin(PI / 2);
	pts[2].x = center.x + radius * cos(5*PI / 6);
	pts[2].y = center.y - radius * sin(5*PI / 6);
	pts[3].x = center.x + radius * cos(7*PI / 6);
	pts[3].y = center.y - radius * sin(7*PI / 6);
	pts[4].x = center.x + radius * cos(6 * PI / 4);
	pts[4].y = center.y - radius * sin(6 * PI / 4);
	pts[5].x = center.x + radius * cos(11 * PI / 6);
	pts[5].y = center.y - radius * sin(11 * PI / 6);

	MY_COLOR c = { 0,0,200 };
	DrawLine(pts[0], pts[2], c);
	DrawLine(pts[2], pts[4], c);
	DrawLine(pts[4], pts[0], c);
	DrawLine(pts[1], pts[3], c);
	DrawLine(pts[3], pts[5], c);
	DrawLine(pts[5], pts[1], c);

}

void display()
{
	glClear(GL_COLOR_BUFFER_BIT); // clean frame buffer

	glDrawPixels(W, H, GL_RGB, GL_UNSIGNED_BYTE, pix);

	glutSwapBuffers(); // show all
}

void idle() 
{
	int i, j;
	double dist,dist1;

	offset += 0.03;
/*
	for (i = 0; i < H; i++)
		for (j = 0; j < W; j++)
		{
			dist = sqrt((double)i*i + j * j);
			dist1 = sqrt((double)(H/2 - i)*(H/2 - i) + (-W/2 - j)*(-W/2 - j));
			pix[i][j][0] = 70+57 * (1 + sin( dist1/50.0-offset)); // R
			pix[i][j][1] = 70 + 57 * (1 + sin(dist1 / 50.0 - offset)); // G
			pix[i][j][2] = 70 + 57 * (1 + sin(dist1 / 50.0 - offset)); // B
		}
		*/
	glutPostRedisplay(); // go to display
}

void mouse(int button, int state, int x, int y) 
{
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		if (!click)// first click: save first point
		{
			click = true; 
			first_point.x=x;
			first_point.y = H - y;// in Window y-axis is opposite to matrix y-axis
		}
		else // second click: DrawLine
		{
			POINT_2D second = { x,H - y };
			MY_COLOR c = { 0,150,255 };
			click = false;
			
			DrawLine(first_point, second,c);
		}
	}
	else if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		DrawFlag();
	}
}

void main(int argc, char* argv[]) 
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
	glutInitWindowSize(W, H);
	glutInitWindowPosition(200, 100);
	glutCreateWindow("City Example");

	glutDisplayFunc(display);
	glutIdleFunc(idle);
	glutMouseFunc(mouse);

	init();

	glutMainLoop();
}